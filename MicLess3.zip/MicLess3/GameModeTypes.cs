﻿
namespace MicLess3;

internal class GameModeTypes
{
    public string EnterGameMode(out string comment, string[,] board)
    {
        comment = "Enter the game mode: Alternative or Classic\n";
        Console.Write(comment);
        string userInput;

        do
        {
            userInput = Console.ReadLine();

            switch (userInput.ToUpper())
            {
                case "ALTERNATIVE":
                    if (userInput.ToUpper() == "ALTERNATIVE")
                    {
                        SecondMode secondMode = new SecondMode();
                        secondMode.SecondGameMode(board);
                    }
                    break;
                case "CLASSIC":
                    break;
                default:
                    Console.WriteLine("Invalid input");
                    break;
            }
        } while (userInput.ToUpper() != "ALTERNATIVE" && userInput.ToUpper() != "CLASSIC");

        return userInput;
    }
}
