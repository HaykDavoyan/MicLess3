﻿namespace MicLess3;

public class SecondMode
{
    public void SecondGameMode(string[,] board)
    {
        PrintEmptyBoard(board);

        Console.WriteLine("Enter the coordinates for the black king");
        AddFigures(board, Console.ReadLine(), "K");

        Console.WriteLine("Enter the coordinates for the first black rook");
        AddFigures(board, Console.ReadLine(), "R");

        Console.WriteLine("Enter the coordinates for the second black rook");
        AddFigures(board, Console.ReadLine(), "R");

        Console.WriteLine("Enter the coordinates for the white king");
        AddFigures(board, Console.ReadLine(), "k");

        PrintChessboard(board);

        Console.WriteLine("Chessboard printed. Press Enter to continue.");
        while (Console.ReadKey().Key != ConsoleKey.Enter) { }
    }

    public void PrintEmptyBoard(string[,] board)
    {
        for (int i = 0; i < board.GetLength(0); i++)
        {
            for (int j = 0; j < board.GetLength(1); j++)
            {
                board[i, j] = " ";
            }
        }
    }

    public void AddFigures(string[,] board, string coordinates, string figure)
    {
        if (coordinates.Length == 2 && char.IsLetter(coordinates[0]) && char.IsDigit(coordinates[1]))
        {
            int col = coordinates[0] - 'a';
            int row = 8 - (coordinates[1] - '0');

            if (row >= 0 && row < board.GetLength(0) && col >= 0 && col < board.GetLength(1))
            {
                board[row, col] = figure;
            }
            else
            {
                Console.WriteLine("Invalid coordinates. Figure not added.");
            }
        }
        else
        {
            Console.WriteLine("Invalid coordinates. Figure not added.");
        }
    }

    public void PrintChessboard(string[,] board)
    {
        Board chessBoard = new Board();
        chessBoard.PrintBoardNew(board);
    }
}
