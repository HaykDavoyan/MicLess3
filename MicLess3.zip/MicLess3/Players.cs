﻿namespace MicLess3;

internal class ChessPlayers
{
    
}
